#### Emoji One Pidgin Theme

 - Applies to the pidgin theme (tarball) and all files in it and any adaptations
   made.
 - License: Creative Commons Attribution-ShareAlike 4.0 International
 - Human Readable License: http://creativecommons.org/licenses/by-sa/4.0/
 - Complete Legal Terms: http://creativecommons.org/licenses/by-sa/4.0/legalcode

#### Source Code for Building

 - License: MIT
 - Complete Legal Terms: http://opensource.org/licenses/MIT
